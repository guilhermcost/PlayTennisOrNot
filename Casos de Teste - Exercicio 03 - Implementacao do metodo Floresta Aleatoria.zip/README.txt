Arquivo zip gerado em: 02/10/2021 17:45:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 03 - Implementação do método Floresta Aleatória